package com.example.message.transformation.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "message.provider.youtube", havingValue = "jms")
public class JMSProducerImpl implements MessageProducer {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSProducerImpl.class);

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${processed.message.queue}")
	private String processedMessageQueue;

	@Override
	public void sendMessage(String message) {
		// LOGGER.info("sending message to JMS Queue='{}'", message);
		jmsTemplate.convertAndSend(processedMessageQueue, message);
	}
}