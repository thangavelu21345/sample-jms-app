package com.telecom.service.response;

public class Item {
	private String kind;
	private Id id;
	private Snippet snippet;
	
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public Id getId() {
		return id;
	}
	public void setId(Id id) {
		this.id = id;
	}
	
	public Snippet getSnippet() {
		return snippet;
	}
	public void setSnippet(Snippet snippet) {
		this.snippet = snippet;
	}
	
	
	@Override
	public String toString() {
		return "Item [kind=" + kind + ", id=" + id + ", snippet=" + snippet + "]";
	}	
}