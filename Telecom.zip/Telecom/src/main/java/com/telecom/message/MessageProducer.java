package com.telecom.message;

public interface MessageProducer {
	public void sendMessage(String message);
}
