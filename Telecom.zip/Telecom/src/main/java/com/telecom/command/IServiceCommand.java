package com.telecom.command;

import com.telecom.service.response.ServiceResponse;

public interface IServiceCommand {
	public ServiceResponse executeSearchCommand(String searchQuery);
}
