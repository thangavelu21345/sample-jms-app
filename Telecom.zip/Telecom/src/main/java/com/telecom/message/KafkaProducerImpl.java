package com.telecom.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name="message.provider.youtube", havingValue="kafka")
public class KafkaProducerImpl implements MessageProducer{
	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaProducerImpl.class);

	@Override
	public void sendMessage(String message) {
		//kafka implementation goes here		
	}
}
