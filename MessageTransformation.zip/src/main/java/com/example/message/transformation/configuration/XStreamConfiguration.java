package com.example.message.transformation.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.message.transformation.message.VideoSearchMessage;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NoTypePermission;

@Configuration
public class XStreamConfiguration {

	@Bean
	@ConditionalOnMissingBean(XStream.class)
	public XStream xstream() {
		XStream xStream = new XStream();
		xStream.processAnnotations(VideoSearchMessage.class);
		xStream.setClassLoader(Thread.currentThread().getContextClassLoader());
		xStream.addPermission(NoTypePermission.NONE);
		xStream.allowTypesByRegExp(new String[] { ".*" });
		return xStream;
	}

}