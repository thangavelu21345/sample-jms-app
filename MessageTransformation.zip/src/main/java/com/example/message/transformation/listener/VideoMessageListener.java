package com.example.message.transformation.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.example.message.transformation.message.MessageProducer;
import com.example.message.transformation.message.VideoSearchMessage;
import com.thoughtworks.xstream.XStream;

@Component
public class VideoMessageListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(VideoMessageListener.class);

	@Autowired
	private MessageProducer messageProducer;
	
	@Autowired
	private XStream xStream;
	
	@JmsListener(destination = "${unprocessed.message.queue}")
	public void receive(String message) {
		LOGGER.info("received message='{}'", message);
		
		VideoSearchMessage videoMessageDetails = (VideoSearchMessage) xStream.fromXML(message);
		
		videoMessageDetails.setTitle(videoMessageDetails.getTitle().replaceAll("\\btelecom\\b", "telco"));
		videoMessageDetails.setTitle(videoMessageDetails.getTitle().replaceAll("\\bTelecom\\b", "Telco"));
		
		messageProducer.sendMessage(xStream.toXML(videoMessageDetails));
		
		System.out.println(videoMessageDetails);
	}
}
