package com.example.message.transformation.message;

public interface MessageProducer {
	public void sendMessage(String message);
}
