package com.telecom.constants;

public class ServiceConstants {
	public static final String SEARCH_QUERY = "telecom";
	public static final String YOU_TUBE_QUERY_PART = "snippet";
	public static final String YOU_TUBE_QUERY_TYPE = "video";	
	public static final int YOU_TUBE_QUERY_MAX_RESULTS = 2;
}
