package com.telecom.service.response;

import java.util.List;

public class ServiceResponse {
	
	private String kind;
	private String nextPageToken;
	private String prevPageToken;
	
	private PageInfo pageInfo;
	
	private List<Item> items;

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getNextPageToken() {
		return nextPageToken;
	}

	public void setNextPageToken(String nextPageToken) {
		this.nextPageToken = nextPageToken;
	}

	public String getPrevPageToken() {
		return prevPageToken;
	}

	public void setPrevPageToken(String prevPageToken) {
		this.prevPageToken = prevPageToken;
	}

	public PageInfo getPageInfo() {
		return pageInfo;
	}

	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		return "YouTubeResponse [kind=" + kind + ", nextPageToken=" + nextPageToken + ", prevPageToken=" + prevPageToken
				+ ", pageInfo=" + pageInfo + ", items=" + items + "]";
	}	
	
	
}