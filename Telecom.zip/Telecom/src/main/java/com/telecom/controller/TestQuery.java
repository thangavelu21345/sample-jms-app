package com.telecom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telecom.response.ResponseVO;
import com.telecom.service.TelecomSearchService;

@RestController
public class TestQuery {

	@Autowired
	private TelecomSearchService telecomSearchService;

	@RequestMapping("/")
	public ResponseVO searchService() {

		ResponseVO responseVo = telecomSearchService.initiateSearch();
		return responseVo;
	}

}