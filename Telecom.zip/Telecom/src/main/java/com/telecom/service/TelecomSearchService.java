package com.telecom.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telecom.constants.ServiceConstants;
import com.telecom.message.MessageProducer;
import com.telecom.message.VideoSearchMessage;
import com.telecom.response.ResponseVO;
import com.telecom.service.invoker.SearchServiceInvoker;
import com.telecom.service.response.Item;
import com.telecom.service.response.ServiceResponse;
import com.telecom.util.FormatUtil;
import com.thoughtworks.xstream.XStream;

@Service
public class TelecomSearchService {

	@Autowired
	private SearchServiceInvoker searchServiceInvoker;

	@Autowired
	private MessageProducer messageProducer;

	public ResponseVO initiateSearch() {

		ServiceResponse serviceResponse = searchServiceInvoker.getServiceResponse(ServiceConstants.SEARCH_QUERY);

		VideoSearchMessage message = null;
		String xmlString = null;

		if (null != serviceResponse) {
			if (null != serviceResponse.getItems() && !serviceResponse.getItems().isEmpty()) {

				for (Item item : serviceResponse.getItems()) {
					message = new VideoSearchMessage();
					message.setTitle(item.getSnippet().getTitle());
					message.setDesc(item.getSnippet().getDescription());
					message.setUrl(FormatUtil.getYouTubeURLFromId(item.getId().getVideoId()));

					XStream xStream = new XStream();
					xStream.processAnnotations(VideoSearchMessage.class);
					xmlString = xStream.toXML(message);

					messageProducer.sendMessage(xmlString);
				}
			}
		}

		ResponseVO responseVo = new ResponseVO();

		responseVo.setStatus("SUCCESS");
		responseVo.setMessage("Search completed and details sent to further ETL jobs");
		return responseVo;
	}
}
