package com.example.message.transformation.message;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("VideoSearchMessage")
public class VideoSearchMessage {
	
	private String title;
	private String desc;
	private String url;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}
