package com.example.message.transformation.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.message.transformation.*")
public class MessageTransformationApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MessageTransformationApplication.class, args);
	}

}