package com.telecom.service.invoker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telecom.command.IServiceCommand;
import com.telecom.service.response.ServiceResponse;

@Service
public class SearchServiceInvoker {
	
	@Autowired
	private IServiceCommand serviceCommand;

	public ServiceResponse getServiceResponse(String searchQuery) {
	
		//logic to check and invoke specific service command
		//currently its checking only one existence of service command and invokes that
		
		ServiceResponse serviceResponse = serviceCommand.executeSearchCommand(searchQuery);
		
		return serviceResponse;
	}
}
