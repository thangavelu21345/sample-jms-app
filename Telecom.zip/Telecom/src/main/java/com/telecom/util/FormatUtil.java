package com.telecom.util;

public class FormatUtil {
	public static String getYouTubeURLFromId(String id) {
		return "https://www.youtube.com/watch?v=" + id;
	}
}
