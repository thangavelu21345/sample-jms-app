package com.telecom.command;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.telecom.constants.ServiceConstants;
import com.telecom.service.response.ServiceResponse;

@Service
public class YouTubeServiceCommand implements IServiceCommand {

	@Value("${youtube.search.url}")
	private String youTubeBaseSearchURL;
	
	@Value("${youtube.api.key}")
	private String youTubeBaseSearchAPIKey;

	@Override
	public ServiceResponse executeSearchCommand(String searchQuery) {

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(youTubeBaseSearchURL)
				.queryParam("part", ServiceConstants.YOU_TUBE_QUERY_PART)
				.queryParam("maxResults", ServiceConstants.YOU_TUBE_QUERY_MAX_RESULTS)
				.queryParam("type", ServiceConstants.YOU_TUBE_QUERY_TYPE)
				.queryParam("key", youTubeBaseSearchAPIKey)
				.queryParam("q", searchQuery);

		HttpEntity<?> entity = new HttpEntity<>(headers);

		RestTemplate restTemplate = new RestTemplate();

		HttpEntity<ServiceResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity,
				ServiceResponse.class);

		ServiceResponse responseObject = response.getBody();
		
		return responseObject;
	}

}
